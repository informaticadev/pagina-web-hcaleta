
import React from 'react';

const specialties = [
  { id: 1, name: 'Cardiología', icon: 'favorite', desc: 'Prevención, diagnóstico y tratamiento de enfermedades cardiovasculares avanzadas.' },
  { id: 2, name: 'Neurología', icon: 'neurology', desc: 'Atención integral del sistema nervioso central y periférico con tecnología de punta.' },
  { id: 3, name: 'Pediatría', icon: 'child_care', desc: 'Cuidado especializado para el crecimiento y desarrollo saludable de tus hijos.' },
  { id: 4, name: 'Diagnóstico', icon: 'radiology', desc: 'Resultados precisos con la tecnología de imagen y laboratorio más avanzada del país.' },
];

export const Services: React.FC = () => {
  return (
    <section className="max-w-[1440px] mx-auto px-8 py-24 bg-gray-50/50">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
        <div className="space-y-4">
          <span className="text-primary font-bold tracking-widest text-sm uppercase">Nuestros Servicios</span>
          <h2 className="text-4xl font-extrabold tracking-tight">Especialidades Médicas</h2>
        </div>
        <p className="text-gray-500 max-w-md text-lg">
          Contamos con infraestructura de última generación y los mejores profesionales para tu cuidado integral.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {specialties.map((spec) => (
          <div
            key={spec.id}
            className="group p-8 rounded-3xl border border-gray-100 bg-white hover:border-primary/20 hover:shadow-2xl hover:shadow-primary/5 transition-all cursor-pointer flex flex-col items-start"
          >
            <div className="size-16 bg-primary/5 rounded-2xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-all mb-8">
              <span className="material-symbols-outlined text-4xl">{spec.icon}</span>
            </div>
            <h3 className="text-xl font-bold mb-3">{spec.name}</h3>
            <p className="text-gray-500 text-sm leading-relaxed mb-6">
              {spec.desc}
            </p>
            <div className="mt-auto h-1 w-0 bg-primary group-hover:w-full transition-all duration-300"></div>
          </div>
        ))}
      </div>
    </section>
  );
};
