
import React from 'react';

const newsItems = [
  {
    tag: 'Tecnología',
    date: '12 Octubre, 2024',
    title: 'Inauguramos nueva unidad de resonancia 3T',
    desc: 'Contamos con la tecnología más avanzada de la región para diagnósticos precisos en menor tiempo y con mayor comodidad para el paciente.',
    img: 'https://picsum.photos/800/500?medical-tech'
  },
  {
    tag: 'Prevención',
    date: '08 Octubre, 2024',
    title: 'Campaña de vacunación pediátrica 2024',
    desc: 'Iniciamos la jornada nacional protegiendo a los más pequeños. Atendemos de forma gratuita en el módulo de pediatría.',
    img: 'https://picsum.photos/800/500?kids'
  },
  {
    tag: 'Institucional',
    date: '01 Octubre, 2024',
    title: 'Acreditación internacional de calidad',
    desc: 'Este sello reafirma nuestro compromiso inquebrantable con la seguridad del paciente y la excelencia médica.',
    img: 'https://picsum.photos/800/500?award'
  }
];

export const News: React.FC = () => {
  return (
    <section className="max-w-[1440px] mx-auto px-8 pb-24">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
        <div className="space-y-4">
          <span className="text-primary font-bold tracking-widest text-sm uppercase">Actualidad</span>
          <h2 className="text-4xl font-extrabold tracking-tight">Noticias Recientes</h2>
        </div>
        <p className="text-gray-500 max-w-md text-lg">
          Mantente informado sobre los últimos avances, campañas de salud y novedades de nuestra institución.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {newsItems.map((news, idx) => (
          <article
            key={idx}
            className="group bg-white rounded-[2.5rem] border border-gray-100 overflow-hidden hover:shadow-2xl hover:shadow-primary/5 transition-all duration-500"
          >
            <div className="aspect-[16/10] overflow-hidden relative">
              <img
                src={news.img}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                alt={news.title}
              />
              <div className="absolute top-6 left-6 bg-white/90 backdrop-blur-md px-4 py-1.5 rounded-full shadow-sm">
                <span className="text-[10px] font-black uppercase text-primary tracking-widest">
                  {news.tag}
                </span>
              </div>
            </div>
            <div className="p-10">
              <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">{news.date}</span>
              <h3 className="text-xl font-extrabold text-navy-deep mt-3 mb-4 leading-tight group-hover:text-primary transition-colors">
                {news.title}
              </h3>
              <p className="text-gray-500 leading-relaxed text-sm mb-8 line-clamp-3">
                {news.desc}
              </p>
              <a href="#" className="flex items-center gap-2 text-primary font-bold text-sm group/link">
                Leer noticia completa
                <span className="material-symbols-outlined text-lg group-hover/link:translate-x-1 transition-transform">
                  arrow_forward
                </span>
              </a>
            </div>
          </article>
        ))}
      </div>
      <div className="flex justify-center">
        <a
          href="#"
          className="group flex items-center gap-3 bg-white border-2 border-primary text-primary px-10 py-4 rounded-2xl font-bold hover:bg-primary hover:text-white transition-all"
        >
          Ver más noticias
          <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">
            arrow_forward
          </span>
        </a>
      </div>
    </section>
  );
};
