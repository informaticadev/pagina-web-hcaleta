
import React from 'react';

interface HeaderProps {
  onMenuClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  return (
    <header className="w-full">
      {/* Top Bar */}
      <div className="w-full bg-navy-deep text-white/80 py-2.5 border-b border-white/5">
        <div className="max-w-[1440px] mx-auto px-8 flex items-center justify-between text-[11px] font-medium tracking-wide">
          <div className="flex items-center gap-6">
            <a 
              className="flex items-center gap-2 hover:text-white transition-colors" 
              href="mailto:mesa_partes@hcaleta.gob.pe"
            >
              <span className="material-symbols-outlined text-sm text-primary">mail</span>
              mesa_partes@hcaleta.gob.pe
            </a>
            <div className="hidden md:flex items-center gap-2 border-l border-white/20 pl-6">
              <span className="material-symbols-outlined text-sm text-primary">schedule</span>
              <span>Lun - Vie: 08:00AM - 15:30PM </span>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-4">
            <span className="text-white/40">Siguenos:</span>
            <div className="flex gap-3">
              <a className="hover:text-primary transition-colors" href="#">FB</a>
              <a className="hover:text-primary transition-colors" href="#">IG</a>
              <a className="hover:text-primary transition-colors" href="#">LI</a>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="sticky z-40 top-0 w-full bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-[1440px] mx-auto px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img 
              src="https://hcaleta.gob.pe/img/logo_caleta_nuevo.png" 
              alt="Logo Caleta" 
              width="200"
              className="object-contain"
            />
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a className="text-sm font-bold text-navy-deep hover:text-primary transition-colors" href="#">Inicio</a>
            <a className="text-sm font-bold text-navy-deep hover:text-primary transition-colors" href="#">Staff</a>
            <a className="text-sm font-bold text-navy-deep hover:text-primary transition-colors" href="#">Servicios</a>
            <a className="text-sm font-bold text-navy-deep hover:text-primary transition-colors" href="#">Noticias</a>
          </div>
          <div className="flex items-center gap-4">
            <button className="hidden lg:block px-6 py-2.5 bg-primary text-white rounded-lg text-sm font-bold shadow-lg shadow-primary/20 hover:scale-[1.02] transition-transform">
              Agendar Cita
            </button>
            <button 
              onClick={onMenuClick}
              className="lg:hidden flex items-center justify-center size-10 text-navy-deep"
              aria-label="Open menu"
            >
              <span className="material-symbols-outlined text-3xl">menu</span>
            </button>
          </div>
        </div>
      </nav>
    </header>
  );
};
