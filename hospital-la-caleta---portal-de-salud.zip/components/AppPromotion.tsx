
import React from 'react';

export const AppPromotion: React.FC = () => {
  return (
    <section className="bg-navy-deep py-24 overflow-hidden">
      <div className="max-w-[1440px] mx-auto px-8 grid grid-cols-1 lg:grid-cols-2 items-center gap-16">
        <div className="space-y-8 text-white">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-mint-green/30">
            <span className="text-mint-green text-[10px] font-bold tracking-widest uppercase">Próximamente</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-extrabold leading-tight">
            Tu salud, <br /> en la palma de tu mano
          </h2>
          <p className="text-white/60 text-lg max-w-md">
            Descarga nuestra app móvil para gestionar tus citas médicas, ver resultados de laboratorio y recibir telemedicina donde sea que estés.
          </p>
          <div className="flex flex-wrap gap-4 pt-4">
            <button className="bg-white/10 hover:bg-white/20 border border-white/20 px-6 py-3 rounded-xl flex items-center gap-3 transition-all group">
              <span className="material-symbols-outlined text-3xl">phone_iphone</span>
              <div className="text-left">
                <p className="text-[10px] opacity-60 uppercase font-bold">Descargar en</p>
                <p className="font-bold">App Store</p>
              </div>
            </button>
            <button className="bg-white/10 hover:bg-white/20 border border-white/20 px-6 py-3 rounded-xl flex items-center gap-3 transition-all group">
              <span className="material-symbols-outlined text-3xl">phone_iphone</span>
              <div className="text-left">
                <p className="text-[10px] opacity-60 uppercase font-bold">Disponible en</p>
                <p className="font-bold">Google Play</p>
              </div>
            </button>
          </div>
        </div>
        <div className="relative flex justify-center">
          <div className="absolute inset-0 bg-primary/20 blur-[100px] rounded-full"></div>
          <div className="relative z-10 flex gap-4 -mb-40">
            <div className="w-64 h-[500px] bg-navy-deep border-[8px] border-white/10 rounded-[40px] overflow-hidden shadow-2xl">
              <img 
                alt="App interface" 
                className="w-full h-full object-cover opacity-80"
                src="https://picsum.photos/400/800?app1" 
              />
            </div>
            <div className="w-64 h-[500px] bg-navy-deep border-[8px] border-white/10 rounded-[40px] overflow-hidden mt-12 shadow-2xl hidden md:block">
              <img 
                alt="App interface 2" 
                className="w-full h-full object-cover opacity-80"
                src="https://picsum.photos/400/800?app2" 
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
