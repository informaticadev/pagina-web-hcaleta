
import React from 'react';

const onlineLinks = [
  { title: 'Citas Médicas', img: 'https://picsum.photos/600/400?booking' },
  { title: 'Resultados', img: 'https://picsum.photos/600/400?results' },
  { title: 'Telemedicina', img: 'https://picsum.photos/600/400?video' },
  { title: 'Pagos Online', img: 'https://picsum.photos/600/400?pay' },
];

export const OnlineServices: React.FC = () => {
  return (
    <section className="max-w-[1440px] mx-auto px-8 py-24">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
        <div className="space-y-4">
          <span className="text-primary font-bold tracking-widest text-sm uppercase">Autoatención</span>
          <h2 className="text-4xl font-extrabold tracking-tight">Servicios en Línea</h2>
        </div>
        <p className="text-gray-500 max-w-md text-lg">
          Accede a nuestros principales servicios digitales de forma rápida y segura, sin salir de casa.
        </p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {onlineLinks.map((item, idx) => (
          <a
            key={idx}
            className="group relative overflow-hidden rounded-3xl bg-white border border-gray-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
            href="#"
          >
            <div className="aspect-[4/3] overflow-hidden relative">
              <img
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                src={item.img}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/60 to-transparent"></div>
            </div>
            <div className="p-6 flex items-center justify-between">
              <h3 className="text-lg font-bold text-navy-deep group-hover:text-primary transition-colors">
                {item.title}
              </h3>
              <span className="material-symbols-outlined text-gray-400 group-hover:text-primary group-hover:translate-x-1 transition-all">
                open_in_new
              </span>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
};
