
import React from 'react';

export const Hero: React.FC = () => {
  return (
    <section className="relative w-full overflow-hidden bg-white">
      <div className="max-w-[1440px] mx-auto grid grid-cols-1 lg:grid-cols-2 min-h-[640px] items-center">
        <div className="px-8 py-16 flex flex-col items-start gap-8">
          <div className="inline-flex items-center gap-2 bg-mint-soft px-3 py-1.5 rounded-full">
            <span className="size-2 bg-primary rounded-full animate-pulse"></span>
            <span className="text-[10px] uppercase font-bold tracking-widest text-primary">
              Vanguardia en Salud
            </span>
          </div>
          <h1 className="text-navy-deep text-5xl lg:text-7xl font-extrabold leading-[1.05] tracking-tight max-w-lg">
            Tu salud es nuestra <span className="text-primary">prioridad</span>
          </h1>
          <p className="text-gray-500 text-lg lg:text-xl font-light leading-relaxed max-w-md">
            Descubre una nueva forma de cuidado médico donde la tecnología y la empatía se unen para tu bienestar.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
            <button className="bg-primary text-white px-10 py-5 rounded-2xl text-lg font-bold shadow-xl shadow-primary/25 hover:-translate-y-1 transition-all active:scale-95">
              Agendar Cita
            </button>
            <button className="flex items-center justify-center gap-2 text-navy-deep border border-gray-200 px-10 py-5 rounded-2xl text-lg font-bold hover:bg-gray-50 transition-all">
              <span className="material-symbols-outlined">call</span>
              Llamar ahora
            </button>
          </div>
          <div className="flex items-center gap-6 mt-4">
            <div className="flex -space-x-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-gray-200 overflow-hidden">
                  <img
                    alt={`Especialista ${i}`}
                    src={`https://picsum.photos/100/100?random=${i}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
            <p className="text-sm text-gray-400 font-medium">+500 Especialistas certificados</p>
          </div>
        </div>
        <div className="hidden lg:block relative h-full min-h-[400px] lg:min-h-0 bg-gray-50 overflow-hidden">
          <img
            alt="Professional healthcare"
            className="absolute inset-0 w-full h-full object-cover"
            src="https://picsum.photos/1000/800?medical"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-white via-transparent to-transparent hidden lg:block"></div>
          <div className="absolute bottom-10 left-10 right-10 lg:right-auto lg:w-72 bg-white/80 backdrop-blur-md p-6 rounded-2xl border border-white shadow-xl">
            <div className="flex items-center gap-3 mb-2">
              <span className="material-symbols-outlined text-primary font-bold">verified_user</span>
              <span className="text-sm font-bold">Certificación Internacional</span>
            </div>
            <p className="text-xs text-gray-600">
              Acreditados por los más altos estándares globales de seguridad y calidad hospitalaria.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
