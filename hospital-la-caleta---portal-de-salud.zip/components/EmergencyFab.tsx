
import React from 'react';

export const EmergencyFab: React.FC = () => {
  return (
    <div className="fixed bottom-10 right-10 z-[60]">
      <button className="group flex items-center gap-3 bg-white border border-soft-red/20 text-soft-red pr-6 pl-2 py-2 rounded-full shadow-lg hover:shadow-soft-red/20 hover:scale-105 transition-all">
        <div className="size-10 bg-soft-red text-white rounded-full flex items-center justify-center animate-pulse">
          <span className="material-symbols-outlined text-xl font-bold">emergency</span>
        </div>
        <div className="flex flex-col items-start leading-tight">
          <span className="text-[9px] uppercase font-black tracking-widest opacity-60">Emergencia 24/7</span>
          <span className="text-sm font-bold text-navy-deep">Llamar Ahora</span>
        </div>
      </button>
    </div>
  );
};
