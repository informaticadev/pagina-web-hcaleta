
import React from 'react';

export const Schedule: React.FC = () => {
  return (
    <section className="max-w-[1440px] mx-auto px-8 bg-gray-100 py-24">
      <div className="text-center mb-16 space-y-4">
        <span className="text-primary font-bold tracking-widest text-sm uppercase">Disponibilidad</span>
        <h2 className="text-4xl font-extrabold tracking-tight">Horarios de Atención</h2>
        <div className="w-16 h-1.5 bg-primary mx-auto rounded-full"></div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Emergencia */}
        <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col items-center text-center group hover:shadow-xl transition-all duration-300">
          <div className="size-14 bg-soft-red/10 text-soft-red rounded-full flex items-center justify-center mb-6">
            <span className="material-symbols-outlined text-3xl font-bold">emergency</span>
          </div>
          <h3 className="text-2xl font-extrabold mb-4">Emergencia</h3>
          <p className="text-primary font-bold text-lg mb-2">Lun - Dom</p>
          <p className="text-gray-400 font-medium tracking-wide">Atención las 24 horas</p>
        </div>

        {/* Consulta Externa */}
        <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col items-center text-center group hover:shadow-xl transition-all duration-300">
          <div className="size-14 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-6">
            <span className="material-symbols-outlined text-3xl">medical_information</span>
          </div>
          <h3 className="text-2xl font-extrabold mb-4">Consulta Externa</h3>
          <div className="space-y-3">
            <div>
              <p className="text-primary font-bold text-sm uppercase tracking-wider">Lunes a Viernes</p>
              <p className="text-navy-deep font-bold text-lg">08:00h - 19:00h</p>
            </div>
            <div>
              <p className="text-primary font-bold text-sm uppercase tracking-wider">Sábados</p>
              <p className="text-navy-deep font-bold text-lg">08:00h - 13:00h</p>
            </div>
          </div>
        </div>

        {/* Atención al Usuario */}
        <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col items-center text-center group hover:shadow-xl transition-all duration-300">
          <div className="size-14 bg-mint-green/10 text-navy-deep rounded-full flex items-center justify-center mb-6">
            <span className="material-symbols-outlined text-3xl">support_agent</span>
          </div>
          <h3 className="text-2xl font-extrabold mb-4">Atención al Usuario</h3>
          <p className="text-primary font-bold text-lg mb-2">Lun - Vie</p>
          <p className="text-navy-deep font-bold text-lg mb-6">08:00h - 15:45h</p>
        </div>
      </div>
    </section>
  );
};
