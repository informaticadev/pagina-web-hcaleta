
import React from 'react';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose }) => {
  return (
    <>
      {/* Overlay */}
      <div 
        className={`fixed inset-0 bg-navy-deep/40 backdrop-blur-sm z-[150] transition-opacity duration-300 lg:hidden ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      
      {/* Sidebar */}
      <aside
        className={`fixed top-0 right-0 h-full w-4/5 max-w-sm bg-white z-[200] transform transition-transform duration-300 ease-in-out shadow-2xl flex flex-col lg:hidden ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
      >
        <div className="p-6 border-b border-gray-100 flex justify-between items-center">
          <img src="https://hcaleta.gob.pe/img/logo_caleta_nuevo.png" width="200" alt="Logo" />
          <button className="p-2" onClick={onClose}>
            <span className="material-symbols-outlined text-gray-500">close</span>
          </button>
        </div>
        <nav className="flex-1 px-6 py-8 flex flex-col gap-6">
          <a className="text-lg font-bold text-navy-deep flex items-center gap-3" href="#" onClick={onClose}>Inicio</a>
          <a className="text-lg font-bold text-navy-deep flex items-center gap-3" href="#" onClick={onClose}>Staff</a>
          <a className="text-lg font-bold text-navy-deep flex items-center gap-3" href="#" onClick={onClose}>Servicios</a>
          <a className="text-lg font-bold text-navy-deep flex items-center gap-3" href="#" onClick={onClose}>Noticias</a>
          <div className="h-px bg-gray-100 my-2"></div>
          <a className="text-lg font-bold text-primary flex items-center gap-3" href="#" onClick={onClose}>Mi Portal</a>
        </nav>
        <div className="p-6 bg-gray-50">
          <button className="w-full bg-primary text-white py-4 rounded-xl font-bold">Agendar Cita</button>
        </div>
      </aside>
    </>
  );
};
