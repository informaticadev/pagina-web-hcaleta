
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-footer-gray pt-20 pb-12">
      <div className="max-w-[1440px] mx-auto px-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12 mb-20">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <img src="https://hcaleta.gob.pe/img/logo_caleta_nuevo.png" width="200" alt="Footer Logo" />
            </div>
            <p className="text-gray-500 text-sm leading-relaxed">
              Referente en salud privada, comprometidos con la excelencia médica y el trato humano desde 1995.
            </p>
            <div className="flex gap-4">
              {['facebook', 'instagram', 'youtube'].map((social, i) => (
                <a
                  key={i}
                  className="w-10 h-10 rounded-full bg-white border border-gray-100 flex items-center justify-center hover:bg-primary hover:text-white transition-all"
                  href="#"
                >
                  <span className="material-symbols-outlined text-xl">share</span>
                </a>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-8 lg:col-span-2">
            <div className="space-y-6">
              <h4 className="font-bold text-navy-deep uppercase text-xs tracking-widest">Institución</h4>
              <ul className="space-y-4 text-sm text-gray-500">
                <li><a className="hover:text-primary transition-colors" href="#">Nosotros</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Directorio Médico</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Responsabilidad Social</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Trabaja con nosotros</a></li>
              </ul>
            </div>
            <div className="space-y-6">
              <h4 className="font-bold text-navy-deep uppercase text-xs tracking-widest">Pacientes</h4>
              <ul className="space-y-4 text-sm text-gray-500">
                <li><a className="hover:text-primary transition-colors" href="#">Prepago y Seguros</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Preguntas Frecuentes</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Canal Ético</a></li>
                <li><a className="hover:text-primary transition-colors" href="#">Derechos y Deberes</a></li>
              </ul>
            </div>
          </div>
          <div className="space-y-6">
            <h4 className="font-bold text-navy-deep uppercase text-xs tracking-widest">Sede Central</h4>
            <div className="h-32 w-full rounded-2xl overflow-hidden border border-gray-200 relative">
              <img 
                alt="Map Location" 
                className="w-full h-full object-cover grayscale opacity-70"
                src="https://picsum.photos/400/300?map" 
              />
              <div className="absolute inset-0 bg-primary/5"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="material-symbols-outlined text-primary text-3xl font-bold">location_on</span>
              </div>
            </div>
            <div className="space-y-2 text-sm text-gray-500">
              <p className="flex items-center gap-2">
                <span className="material-symbols-outlined text-lg">pin_drop</span> Av. Malecon Grau s/n - Urb. La Caleta
              </p>
              <p className="flex items-center gap-2">
                <span className="material-symbols-outlined text-lg">call</span> +51 043327589
              </p>
            </div>
          </div>
        </div>
        <div className="pt-8 border-t border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-400">
          <p>© 2026 Hospital La Caleta. Todos los derechos reservados.</p>
          <div className="flex gap-6">
            <a className="hover:text-navy-deep" href="#">Política de Privacidad</a>
            <a className="hover:text-navy-deep" href="#">Cookies</a>
            <a className="hover:text-navy-deep" href="#">Términos y Condiciones</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
