
import React, { useState } from 'react';
import { Header } from './components/Header';
import { MobileMenu } from './components/MobileMenu';
import { Hero } from './components/Hero';
import { Schedule } from './components/Schedule';
import { Services } from './components/Services';
import { AppPromotion } from './components/AppPromotion';
import { OnlineServices } from './components/OnlineServices';
import { News } from './components/News';
import { Footer } from './components/Footer';
import { EmergencyFab } from './components/EmergencyFab';

const App: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <div className="relative">
      <MobileMenu isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} />
      
      <Header onMenuClick={toggleMenu} />
      
      <main>
        <Hero />
        <Schedule />
        <Services />
        <AppPromotion />
        <OnlineServices />
        <News />
      </main>

      <Footer />
      <EmergencyFab />
    </div>
  );
};

export default App;
